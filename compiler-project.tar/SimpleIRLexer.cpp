
// Generated from SimpleIR.g4 by ANTLR 4.10


#include "SimpleIRLexer.h"


using namespace antlr4;



using namespace antlr4;

namespace {

struct SimpleIRLexerStaticData final {
  SimpleIRLexerStaticData(std::vector<std::string> ruleNames,
                          std::vector<std::string> channelNames,
                          std::vector<std::string> modeNames,
                          std::vector<std::string> literalNames,
                          std::vector<std::string> symbolicNames)
      : ruleNames(std::move(ruleNames)), channelNames(std::move(channelNames)),
        modeNames(std::move(modeNames)), literalNames(std::move(literalNames)),
        symbolicNames(std::move(symbolicNames)),
        vocabulary(this->literalNames, this->symbolicNames) {}

  SimpleIRLexerStaticData(const SimpleIRLexerStaticData&) = delete;
  SimpleIRLexerStaticData(SimpleIRLexerStaticData&&) = delete;
  SimpleIRLexerStaticData& operator=(const SimpleIRLexerStaticData&) = delete;
  SimpleIRLexerStaticData& operator=(SimpleIRLexerStaticData&&) = delete;

  std::vector<antlr4::dfa::DFA> decisionToDFA;
  antlr4::atn::PredictionContextCache sharedContextCache;
  const std::vector<std::string> ruleNames;
  const std::vector<std::string> channelNames;
  const std::vector<std::string> modeNames;
  const std::vector<std::string> literalNames;
  const std::vector<std::string> symbolicNames;
  const antlr4::dfa::Vocabulary vocabulary;
  antlr4::atn::SerializedATNView serializedATN;
  std::unique_ptr<antlr4::atn::ATN> atn;
};

std::once_flag simpleirlexerLexerOnceFlag;
SimpleIRLexerStaticData *simpleirlexerLexerStaticData = nullptr;

void simpleirlexerLexerInitialize() {
  assert(simpleirlexerLexerStaticData == nullptr);
  auto staticData = std::make_unique<SimpleIRLexerStaticData>(
    std::vector<std::string>{
      "T__0", "T__1", "T__2", "T__3", "T__4", "T__5", "T__6", "T__7", "T__8", 
      "T__9", "T__10", "NAME", "NUM", "PLUS", "MINUS", "STAR", "SLASH", 
      "PERCENT", "EQ", "NEQ", "LT", "LTE", "GT", "GTE", "WS", "COMMENT"
    },
    std::vector<std::string>{
      "DEFAULT_TOKEN_CHANNEL", "HIDDEN"
    },
    std::vector<std::string>{
      "DEFAULT_MODE"
    },
    std::vector<std::string>{
      "", "'function'", "'localVariables'", "'parameters'", "'return'", 
      "'end'", "':='", "'&'", "'call'", "':'", "'goto'", "'if'", "", "", 
      "'+'", "'-'", "'*'", "'/'", "'%'", "'='", "'!='", "'<'", "'<='", "'>'", 
      "'>='"
    },
    std::vector<std::string>{
      "", "", "", "", "", "", "", "", "", "", "", "", "NAME", "NUM", "PLUS", 
      "MINUS", "STAR", "SLASH", "PERCENT", "EQ", "NEQ", "LT", "LTE", "GT", 
      "GTE", "WS", "COMMENT"
    }
  );
  static const int32_t serializedATNSegment[] = {
  	4,0,26,172,6,-1,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
  	6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,
  	7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,
  	7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,1,0,1,0,1,0,1,0,1,0,1,0,
  	1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
  	1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,
  	1,3,1,4,1,4,1,4,1,4,1,5,1,5,1,5,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,
  	9,1,9,1,9,1,9,1,9,1,10,1,10,1,10,1,11,1,11,5,11,122,8,11,10,11,12,11,
  	125,9,11,1,12,4,12,128,8,12,11,12,12,12,129,1,13,1,13,1,14,1,14,1,15,
  	1,15,1,16,1,16,1,17,1,17,1,18,1,18,1,19,1,19,1,19,1,20,1,20,1,21,1,21,
  	1,21,1,22,1,22,1,23,1,23,1,23,1,24,4,24,158,8,24,11,24,12,24,159,1,24,
  	1,24,1,25,1,25,5,25,166,8,25,10,25,12,25,169,9,25,1,25,1,25,0,0,26,1,
  	1,3,2,5,3,7,4,9,5,11,6,13,7,15,8,17,9,19,10,21,11,23,12,25,13,27,14,29,
  	15,31,16,33,17,35,18,37,19,39,20,41,21,43,22,45,23,47,24,49,25,51,26,
  	1,0,5,3,0,65,90,95,95,97,122,4,0,48,57,65,90,95,95,97,122,1,0,48,57,3,
  	0,9,10,13,13,32,32,2,0,10,10,13,13,175,0,1,1,0,0,0,0,3,1,0,0,0,0,5,1,
  	0,0,0,0,7,1,0,0,0,0,9,1,0,0,0,0,11,1,0,0,0,0,13,1,0,0,0,0,15,1,0,0,0,
  	0,17,1,0,0,0,0,19,1,0,0,0,0,21,1,0,0,0,0,23,1,0,0,0,0,25,1,0,0,0,0,27,
  	1,0,0,0,0,29,1,0,0,0,0,31,1,0,0,0,0,33,1,0,0,0,0,35,1,0,0,0,0,37,1,0,
  	0,0,0,39,1,0,0,0,0,41,1,0,0,0,0,43,1,0,0,0,0,45,1,0,0,0,0,47,1,0,0,0,
  	0,49,1,0,0,0,0,51,1,0,0,0,1,53,1,0,0,0,3,62,1,0,0,0,5,77,1,0,0,0,7,88,
  	1,0,0,0,9,95,1,0,0,0,11,99,1,0,0,0,13,102,1,0,0,0,15,104,1,0,0,0,17,109,
  	1,0,0,0,19,111,1,0,0,0,21,116,1,0,0,0,23,119,1,0,0,0,25,127,1,0,0,0,27,
  	131,1,0,0,0,29,133,1,0,0,0,31,135,1,0,0,0,33,137,1,0,0,0,35,139,1,0,0,
  	0,37,141,1,0,0,0,39,143,1,0,0,0,41,146,1,0,0,0,43,148,1,0,0,0,45,151,
  	1,0,0,0,47,153,1,0,0,0,49,157,1,0,0,0,51,163,1,0,0,0,53,54,5,102,0,0,
  	54,55,5,117,0,0,55,56,5,110,0,0,56,57,5,99,0,0,57,58,5,116,0,0,58,59,
  	5,105,0,0,59,60,5,111,0,0,60,61,5,110,0,0,61,2,1,0,0,0,62,63,5,108,0,
  	0,63,64,5,111,0,0,64,65,5,99,0,0,65,66,5,97,0,0,66,67,5,108,0,0,67,68,
  	5,86,0,0,68,69,5,97,0,0,69,70,5,114,0,0,70,71,5,105,0,0,71,72,5,97,0,
  	0,72,73,5,98,0,0,73,74,5,108,0,0,74,75,5,101,0,0,75,76,5,115,0,0,76,4,
  	1,0,0,0,77,78,5,112,0,0,78,79,5,97,0,0,79,80,5,114,0,0,80,81,5,97,0,0,
  	81,82,5,109,0,0,82,83,5,101,0,0,83,84,5,116,0,0,84,85,5,101,0,0,85,86,
  	5,114,0,0,86,87,5,115,0,0,87,6,1,0,0,0,88,89,5,114,0,0,89,90,5,101,0,
  	0,90,91,5,116,0,0,91,92,5,117,0,0,92,93,5,114,0,0,93,94,5,110,0,0,94,
  	8,1,0,0,0,95,96,5,101,0,0,96,97,5,110,0,0,97,98,5,100,0,0,98,10,1,0,0,
  	0,99,100,5,58,0,0,100,101,5,61,0,0,101,12,1,0,0,0,102,103,5,38,0,0,103,
  	14,1,0,0,0,104,105,5,99,0,0,105,106,5,97,0,0,106,107,5,108,0,0,107,108,
  	5,108,0,0,108,16,1,0,0,0,109,110,5,58,0,0,110,18,1,0,0,0,111,112,5,103,
  	0,0,112,113,5,111,0,0,113,114,5,116,0,0,114,115,5,111,0,0,115,20,1,0,
  	0,0,116,117,5,105,0,0,117,118,5,102,0,0,118,22,1,0,0,0,119,123,7,0,0,
  	0,120,122,7,1,0,0,121,120,1,0,0,0,122,125,1,0,0,0,123,121,1,0,0,0,123,
  	124,1,0,0,0,124,24,1,0,0,0,125,123,1,0,0,0,126,128,7,2,0,0,127,126,1,
  	0,0,0,128,129,1,0,0,0,129,127,1,0,0,0,129,130,1,0,0,0,130,26,1,0,0,0,
  	131,132,5,43,0,0,132,28,1,0,0,0,133,134,5,45,0,0,134,30,1,0,0,0,135,136,
  	5,42,0,0,136,32,1,0,0,0,137,138,5,47,0,0,138,34,1,0,0,0,139,140,5,37,
  	0,0,140,36,1,0,0,0,141,142,5,61,0,0,142,38,1,0,0,0,143,144,5,33,0,0,144,
  	145,5,61,0,0,145,40,1,0,0,0,146,147,5,60,0,0,147,42,1,0,0,0,148,149,5,
  	60,0,0,149,150,5,61,0,0,150,44,1,0,0,0,151,152,5,62,0,0,152,46,1,0,0,
  	0,153,154,5,62,0,0,154,155,5,61,0,0,155,48,1,0,0,0,156,158,7,3,0,0,157,
  	156,1,0,0,0,158,159,1,0,0,0,159,157,1,0,0,0,159,160,1,0,0,0,160,161,1,
  	0,0,0,161,162,6,24,0,0,162,50,1,0,0,0,163,167,5,35,0,0,164,166,8,4,0,
  	0,165,164,1,0,0,0,166,169,1,0,0,0,167,165,1,0,0,0,167,168,1,0,0,0,168,
  	170,1,0,0,0,169,167,1,0,0,0,170,171,6,25,0,0,171,52,1,0,0,0,6,0,121,123,
  	129,159,167,1,6,0,0
  };
  staticData->serializedATN = antlr4::atn::SerializedATNView(serializedATNSegment, sizeof(serializedATNSegment) / sizeof(serializedATNSegment[0]));

  antlr4::atn::ATNDeserializer deserializer;
  staticData->atn = deserializer.deserialize(staticData->serializedATN);

  const size_t count = staticData->atn->getNumberOfDecisions();
  staticData->decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    staticData->decisionToDFA.emplace_back(staticData->atn->getDecisionState(i), i);
  }
  simpleirlexerLexerStaticData = staticData.release();
}

}

SimpleIRLexer::SimpleIRLexer(CharStream *input) : Lexer(input) {
  SimpleIRLexer::initialize();
  _interpreter = new atn::LexerATNSimulator(this, *simpleirlexerLexerStaticData->atn, simpleirlexerLexerStaticData->decisionToDFA, simpleirlexerLexerStaticData->sharedContextCache);
}

SimpleIRLexer::~SimpleIRLexer() {
  delete _interpreter;
}

std::string SimpleIRLexer::getGrammarFileName() const {
  return "SimpleIR.g4";
}

const std::vector<std::string>& SimpleIRLexer::getRuleNames() const {
  return simpleirlexerLexerStaticData->ruleNames;
}

const std::vector<std::string>& SimpleIRLexer::getChannelNames() const {
  return simpleirlexerLexerStaticData->channelNames;
}

const std::vector<std::string>& SimpleIRLexer::getModeNames() const {
  return simpleirlexerLexerStaticData->modeNames;
}

const dfa::Vocabulary& SimpleIRLexer::getVocabulary() const {
  return simpleirlexerLexerStaticData->vocabulary;
}

antlr4::atn::SerializedATNView SimpleIRLexer::getSerializedATN() const {
  return simpleirlexerLexerStaticData->serializedATN;
}

const atn::ATN& SimpleIRLexer::getATN() const {
  return *simpleirlexerLexerStaticData->atn;
}




void SimpleIRLexer::initialize() {
  std::call_once(simpleirlexerLexerOnceFlag, simpleirlexerLexerInitialize);
}
